## categories:
- Academic Concerns: Topics related to courses, assignments, exams, study resources, etc.

- Administrative Issues: Discussions on university policies, tuition, administration services, etc.
- Campus Life: Posts about events, clubs, campus facilities, student life, etc.
- Advice Seeking: Requests for advice on various topics such as housing, personal issues, etc.
- Experiences & Opinions: Sharing of personal experiences, opinions on different matters, feedback on courses or services, etc.
- Miscellaneous: Any posts that do not fit into the above categories or are off-topic, humorous, or unusual in nature.